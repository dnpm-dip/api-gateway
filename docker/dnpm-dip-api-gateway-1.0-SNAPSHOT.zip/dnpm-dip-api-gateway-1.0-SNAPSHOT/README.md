# DNPM:DIP - REST API Gateway

REST API Gateway component to expose DNPM:DIP modules 

**WORK IN PROGRESS**


## API Docs (Preliminary):

[https://github.com/KohlbacherLab/dnpm-dip-api-gateway/blob/main/app/controllers/README.md](https://github.com/KohlbacherLab/dnpm-dip-api-gateway/blob/main/app/controllers/README.md)

